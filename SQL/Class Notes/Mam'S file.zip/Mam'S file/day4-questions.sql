
# Problem Statements
/*
- increase salary by 10% for JOB_ID = 'AD_PRES'
- increase salary by 20% for JOB_ID = 'IT_PROG'
- keep salary for other JOB_IDs as it is.
*/

/*
- increase salary by 10% for JOB_ID = 'AD_PRES'
- increase salary by 20% for EMP_ID = 104
- keep other salaries as it is.
*/

/*
- display PAY_LEVEL for every employee as
- 'LOW'		: when PAY_LEVEL is less than 10000
- 'MEDIUM'	: when PAY_LEVEL is less than 20000
- 'HIGH'	: when PAY_LEVEL is greater than or equals to 20000
*/

/*
- Get details of employees from myemp table
- display the results in 
		1. Descending order of COMMISION_PCT for sales employees
		2. Descending order of SALARY for other employees
*/







