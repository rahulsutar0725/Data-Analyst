-- ctrl + shift + enter

CREATE DATABASE day7;
USE day7;

CREATE TABLE table1(
	column1 CHAR(1),
    column2 CHAR(2)
);
INSERT INTO table1 VALUES ('A', 'AA'), ('B', 'BB'), ('C', 'CC');

CREATE TABLE table2(
	column1 CHAR(1),
    column3 CHAR(3)
);
INSERT INTO table2 VALUES ('A', 'AAA'), ('B', 'BBB'), ('D', 'DDD');

CREATE TABLE table3(
	column4 CHAR(3),
    column5 CHAR(4)
);
INSERT INTO table3 VALUES ('AAA', 'AAAA'), ('EEE', 'EEEE');








