-- create table without constraints

create database day6;
use day6;
create table user0 (
uid int,
uname varchar(25),
age int,
isAdmin varchar(5)
);

-- inserting valus into table without constraints
insert into user0 values (101,'ABC',34,'NO');
insert into user0 values (101,'PQR',23,'NO'); -- accepting duplicate values
insert into user0 values (101,null,34,'yes'); -- accept null
insert into user0 values (102,'xyz',-4,'NO'); -- accept invalid values
insert into user0 (uid,uname,age) values (104,'jkl',23); -- defalult valu is null
select * from user0;

-- create table with constraints
create table user1 (
uid int unique,
uname varchar(25) not null,
age int check (age>=13),
isAdmin varchar(5) default 'NO'
);

insert into user1 values (101,'ABC',34,'NO');
insert into user1 values (101,'pqr',23,'NO');
insert into user1 values (102,null,20,'yes');
insert into user1 values (103,'dfg',-5,'NO');

insert into user1 (uid,uname,age) values (104,'jkl',23); -- default value for isadmin is NO 




			-- Primery Key
-- it is col or combination of column that uniquely identify each record in table
-- unique+not null 
-- there is only one primery key for table
-- primery key could be made up of one or more col


create table students (
sid int primary key auto_increment, 
sname varchar(25) not null
);

insert into students values (1,'abc');
insert into students values (2,'abc');
insert into students values (2,'pqr');
insert into students values (null,'xyz');
insert into students (sname) values ('xyz');
insert into students (sname) values ('ppp');


create table students1 (
sid int primary key , 
sname varchar(25) not null
);

insert into students1 values (1,'abc');
insert into students1 values (2,'abc');
insert into students1 values (2,'pqr');
insert into students1 values (null,'xyz');
insert into students1 (sname) values ('xyz');
insert into students1 (sname) values ('ppp');

-- combination of primery key
create table students2 (
section int,
sid int , 
sname varchar(25) not null,
primary key (section,sid) -- combi of primery key
);
insert into students2 values (101,1,'abc');
insert into students2 values (101,2,'pqr');
insert into students2 values (101,2,'qwe'); -- duplicate entry for primery key combinationof primery key
insert into students2 values (102,1,'qwe');

		-- Day 10
