# LOOP statement: to run a block of code repeatedly based on a condition.

# Cursor
/* 
- A cursor allows you to iterate a set of rows returned by a query and process each row individually.
- MySQL cursor is read-only, non-scrollable and asensitive.
*/






































